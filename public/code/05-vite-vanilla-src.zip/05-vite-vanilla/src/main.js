// ═══════════════════════════════════════════════════════════
// main.js —— 整个前端应用的入口
// 浏览器加载 index.html → 遇到 <script type="module" src="/src/main.js">
// → Vite 服务器拦截请求，实时把这份源码翻译成浏览器能跑的 JS
// ═══════════════════════════════════════════════════════════

// ① 导入样式：在原生浏览器里"import 一个 css"是违法的，
//    是 Vite 让它合法——读到 css 后注入 <style> 标签进页面
import './style.css';

// ② 从另一个模块导入函数：这就是 ES Module（02 第 18 节细讲）
//    注意路径 ./ 表示同目录下；模块化让代码各管各的文件
import { setupCounter } from './counter.js';

// ③ 找到 HTML 里 id="counter" 的按钮
//    document.querySelector 是 DOM 操作的基本功（02 第 14 节细讲）
const counterEl = document.querySelector('#counter');

// ④ 把"计数器逻辑"装配到按钮上
setupCounter(counterEl);
