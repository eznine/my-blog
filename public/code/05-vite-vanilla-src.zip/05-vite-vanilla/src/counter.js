// ═══════════════════════════════════════════════════════════
// counter.js —— 一个独立模块：只管"计数器"这一件事
// 模块化的意义：功能拆文件、各司其职、可以复用
// ═══════════════════════════════════════════════════════════

/**
 * 把计数器行为装到指定按钮上
 * @param {HTMLElement} button - 页面上的按钮元素
 */
export function setupCounter(button) {
  // 闭包变量：点击次数存在这里，外面的代码碰不到（02 第 33 节会深挖）
  let count = 0;

  // 定义"更新按钮文字"的小函数
  const render = () => {
    button.innerHTML = `点了 ${count}`;
  };

  // 监听点击事件：每点一次 count 加一，然后重新渲染（02 第 15 节细讲）
  button.addEventListener('click', () => {
    count += 1;
    render();
  });

  // 初始先渲染一次（显示 count is 0）
  render();
}
